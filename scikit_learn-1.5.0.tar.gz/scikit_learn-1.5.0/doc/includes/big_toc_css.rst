..  
    File to ..include in a document with a big table of content, to give
    it 'style'

.. raw:: html

  <style type="text/css">
    div.body div.toctree-wrapper ul {
        padding-left: 0;
    }

    div.body li.toctree-l1 {
        padding: 0 0 0.5em 0;
        list-style-type: none;
        font-size: 150%;
        font-weight: bold;
    }

    div.body li.toctree-l2 {
        font-size: 70%;
        list-style-type: square;
        font-weight: normal;
        margin-left: 40px;
    }

    div.body li.toctree-l3 {
        font-size: 85%;
        list-style-type: circle;
        font-weight: normal;
        margin-left: 40px;
    }

    div.body li.toctree-l4 {
        margin-left: 40px;
    }
 
  </style>



